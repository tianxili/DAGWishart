rm(list=ls())
require(doParallel)
#cl <- makeCluster(4)
#registerDoParallel(cl)
#trials <- 100
#ptime <- system.time(
# {
 # r <- foreach(icount(trials)) %dopar% {
  # tt <- rnorm(1)
  #}
 #}
#)

registerDoParallel(cores=12)
alpha.seq <- c(rep(1,7),seq(10,50,by=10))
b.seq <- c(seq(360,60,by=-60),rep(3,6))
r <- foreach(i=1:12) %dopar%{
source("PerfEval-Final.R") 

PerformanceEvaluation(M=10,p=200,n=100,sparsity=0.01,strength=0.5,u=1,alpha=alpha.seq[i],b=b.seq[i],seed=509,X1=30,X3=0,iter=100,LassoNum=2,gm=0.5)

}

#save(r,file="NewEvalTestp0-HyperPar-Sparse.Rda")

EvalSum <- NULL
for(k in 1:length(r)) EvalSum <- rbind(EvalSum,r[[k]]$Eval)
save(EvalSum,file="p200-ModelSelect-HyperPar-Part3.Rda")







