library(glmnet)
library(pcalg)

## Simple - non-intercept Lasso : This is function to deal with the single variable lasso without an intercept. Since glmnet cannot do it this case
## L = RSS/2n + lambda * |beta|

Sim.NonInter.Lasso <- function(x,y,lambda){
    Sxy <- t(x)%*%y
    Sxx <- t(x)%*%x
    n <- length(x)
    if(Sxy>(n*lambda)) return(matrix((Sxy-lambda*n)/Sxx,1,1))
    if(Sxy< - (n*lambda)) return(matrix((Sxy+n*lambda)/Sxx,1,1))
    return(matrix(0,1,1))
}




## DAGLasso is the penalized likelihood estimation proposed in Shojaie & Michailidis (2010).
# 1. adaptive = TRUE means using adaptive lasso
# 2. lambda.seq is the sequence of lambda with the length as p of the graph. This is the lasso penalty parameter for each row of adjacency matrix. Formula (3.8) in the paper
# 3. gm is the power parameter used in the adaptive lasso in Zou (2006)


DAGLasso <- function(x,lambda.seq,adaptive=FALSE,gm=1){
    p <- ncol(x)
    n <- nrow(x)
    X <- scale(x,center=TRUE,scale=TRUE)

    if(length(lambda.seq)==1) lambda.seq <- rep(lambda.seq,p)

    Adj <- matrix(0,p,p) ## Adjacency matrix
    for(i in 2:p){
        tmp.y <- X[,i]
        tmp.x <- X[,1:(i-1)]
        if(!adaptive){
            if(i==2){
                theta <- Sim.NonInter.Lasso(x=tmp.x,y=tmp.y,lambda=0.5*lambda.seq[i])
            }
            if(i>2){
                lasso.md <- glmnet(x=tmp.x,y=tmp.y,family="gaussian",lambda=0.5*lambda.seq[i],intercept=FALSE)
                theta <- as.matrix(lasso.md$beta)
            }
            Adj[i,1:(i-1)] <- t(theta)
        }
        if(adaptive){
            if(p < n){
                ## use inverse of OLS coefficients as weights
                ini.lm <- lm(tmp.y~tmp.x-1)
                if(i==2) w.inverse <- matrix(ini.lm$coef^gm,1,1)
                if(i>2) w.inverse <- diag(ini.lm$coef^gm)
                w.inverse[w.inverse>1] <- 1
            }
            if(p >= n){
                # use inverse of the ridge coefficients as weights
                if(i>2) ini.ridge <- glmnet(x=tmp.x,y=tmp.y,family="gaussian",intercept=FALSE,alpha=0)
                if(i==2) w.inverse <- matrix((mean(tmp.x*tmp.y)/(mean(tmp.x^2)-lambda.seq[i]))^gm,1,1)
                if(i>2) w.inverse <- diag(as.numeric(ini.ridge$beta[,ncol(ini.ridge$beta)])^gm)
                w.inverse <- abs(w.inverse)
                w.inverse[w.inverse>1] <- 1
            }
            tmp.x <- tmp.x %*% w.inverse
            if(i==2){
                theta <- Sim.NonInter.Lasso(x=tmp.x,y=tmp.y,lambda=0.5*lambda.seq[i])
            }
            if(i>2){
                lasso.md <- glmnet(x=tmp.x,y=tmp.y,family="gaussian",lambda=0.5*lambda.seq[i],intercept=FALSE)
                theta <- w.inverse %*% as.matrix(lasso.md$beta)
            }
            #lasso.md <- glmnet(x=tmp.x,y=tmp.y,family="gaussian",lambda=2*lambda.seq[i],intercept=FALSE)
            #theta <- w.inverse %*% as.matrix(lasso.md$beta)
            Adj[i,1:(i-1)] <- t(theta)
        }
    }

    return(Adj)

}

### Function to get diagonal submatrix
## U: orignal matrix
## ind: index of elements to get

GetDiagSub <- function(ind,U){
    return(U[ind,ind])
}

## SpecialDet: function to calculate determinant of a square matrix, with special case checking
SpecialDet <- function(x){
    if(length(x)==0) return(1)
    if(length(x)==1) return(as.numeric(x))
    return(det(x))
}

## Expectation of Sigma from DAG Wishart distribution. Adj: adjacency matrix of the graph; U and alpha are the hyperparameters
DAGWishart.expect <- function(Adj,U,alpha){
    print("Call DAGWishart.expect!")
    m <- nrow(Adj)
    if((m!=ncol(Adj))||(m!=length(alpha))) stop("Dimension Incorrect!")
    pa.set <- apply(Adj,2,function(x){which(x!=0)})
    E.mat <- matrix(0,m,m)
    E.mat[m,m] <- U[m,m]/(alpha[m]-4)
    if(length(pa.set)>0){
        pa.count <- unlist(lapply(pa.set,length))
        for(i in seq(m-1,1)){
            if(pa.count[i]==0){
                E.mat[i,i] <- U[i,i]/(alpha[i]-4)
            }
            if(pa.count[i]>0){
                Upa <- GetDiagSub(pa.set[[i]],U)
                Upa.invert <- solve(Upa)
                Epa <- GetDiagSub(pa.set[[i]],E.mat)
                E.mat[pa.set[[i]],i] <- (-1)*Epa%*%Upa.invert%*%U[pa.set[[i]],i]
                Ucond <- U[i,i] - U[i,pa.set[[i]]]%*%Upa.invert%*%U[pa.set[[i]],i]
                TT <- Epa%*%(as.numeric(Ucond/(alpha[i]-pa.count[i]-4))*Upa.invert+Upa.invert%*%U[pa.set[[i]],i]%*%U[i,pa.set[[i]]]%*%Upa.invert)
                E.mat[i,i] <- Ucond/(alpha[i]-pa.count[i]-4) + sum(diag(TT))
                if((m-i)-pa.count[i]>0){
                  tmp.non.pa.set <- setdiff((i+1):m,pa.set[[i]])
                  E.mat[tmp.non.pa.set,i] <- matrix(E.mat[tmp.non.pa.set,pa.set[[i]]],nrow=length(tmp.non.pa.set))%*%matrix(solve(Epa,E.mat[pa.set[[i]],i]),ncol=1)
                }
            }
            E.mat[i,(i+1):m] <- E.mat[(i+1):m,i]
        }
    }
    print("End DAGWishart.expect2!")
    return(E.mat)
}


DAG.MLE <- function(S,Adj){
    #print("Call DAG MLE!")
    m <- nrow(S)
    Psi <- matrix(0,m,m)
    #if(m>=1000){
     #   S <- S + diag(rep(0.01,m))
    #}
    Psi[m,m] <- S[m,m]
    pa.set <- apply(Adj,2,function(x){which(x!=0)})
    if(length(pa.set)==0){
        diag(Psi) <- diag(S)
        return(Psi)
    }
    pa.count <- unlist(lapply(pa.set,length))
    for(i in seq(m-1,1)){
        if(pa.count[i]==0){
            Psi[i,i] <- S[i,i]
        }
        if(pa.count[i]>0){
            Spa <- GetDiagSub(pa.set[[i]],S)
            Spa.invert <- solve(Spa)
            Psipa <- matrix(GetDiagSub(pa.set[[i]],Psi),ncol=pa.count[i])
            beta <- matrix(Spa.invert%*%S[pa.set[[i]],i],ncol=1)
            Psi[pa.set[[i]],i] <- Psipa%*%beta
            lambda <- S[i,i] - as.numeric(matrix(S[i,pa.set[[i]]],nrow=1)%*%beta)
            Psi[i,i] <- lambda + as.numeric(t(beta)%*%Psipa%*%beta)
            if((m-i)-pa.count[i]>0){
                non.pa.set <- setdiff((i+1):m,pa.set[[i]])
                Psi[non.pa.set,i] <- Psi[non.pa.set,pa.set[[i]]]%*%solve(Psipa)%*%Psi[pa.set[[i]],i]
            }
        }
        Psi[i,] <- Psi[,i]
        if(any(Psi[i,]>1e10)) break
    }
    #print("End DAG MLE!")
    return(Psi)
}



DAG.MAP <- function(S,Adj,U,alpha.c,alpha.b,n){
    #print("Call DAG MAP!")
    m <- nrow(S)
    Psi <- matrix(0,m,m)
    S <- n*S + U
    alpha <- rep(alpha.b,m)
    Psi[m,m] <- S[m,m]/(alpha[m]+n)
    pa.set <- apply(Adj,2,function(x){which(x!=0)})
    if(length(pa.set)==0){
        diag(Psi) <- diag(S)/(alpha+n)
        return(Psi)
    }
    pa.count <- unlist(lapply(pa.set,length))
    if(length(pa.set)>0){
    	alpha <- alpha + alpha.c*pa.count
    }

    for(i in seq(m-1,1)){
        if(pa.count[i]==0){
            Psi[i,i] <- S[i,i]/(alpha[i]+n)
        }
        if(pa.count[i]>0){
            Spa <- GetDiagSub(pa.set[[i]],S)
            Spa.invert <- solve(Spa)
            Psipa <- matrix(GetDiagSub(pa.set[[i]],Psi),ncol=pa.count[i])
            beta <- matrix(Spa.invert%*%S[pa.set[[i]],i],ncol=1)
            Psi[pa.set[[i]],i] <- Psipa%*%beta
            lambda <- (S[i,i] - as.numeric(matrix(S[i,pa.set[[i]]],nrow=1)%*%beta))/(alpha[i]+n)
            Psi[i,i] <- lambda + as.numeric(t(beta)%*%Psipa%*%beta)
            if((m-i)-pa.count[i]>0){
                non.pa.set <- setdiff((i+1):m,pa.set[[i]])
                Psi[non.pa.set,i] <- Psi[non.pa.set,pa.set[[i]]]%*%solve(Psipa)%*%Psi[pa.set[[i]],i]
            }
        }
        Psi[i,] <- Psi[,i]
        if(any(Psi[i,]>1e10)) break
    }
    #print("End DAG MAP!")
    return(Psi)
}



DAGWishart.expect2 <- function(Adj,U,alpha){
    print("Call DAGWishart.expect2!")
    m <- nrow(Adj)
    if((m!=ncol(Adj))||(m!=length(alpha))) stop("Dimension Incorrect!")
    pa.set <- apply(Adj,2,function(x){which(x!=0)})
    E.mat <- matrix(0,m,m)
    E.mat[m,m] <- U[m,m]/(alpha[m]-4)
    if(length(pa.set)>0){
        pa.count <- unlist(lapply(pa.set,length))
        for(i in seq(m-1,1)){
            if(pa.count[i]==0){
                E.mat[i,i] <- U[i,i]/(alpha[i]-4)
            }
            if(pa.count[i]>0){
                Upa <- GetDiagSub(pa.set[[i]],U)
                Upa.inver.pai <- matrix(solve(Upa,U[pa.set[[i]],i]),ncol=1)
                Epa <- GetDiagSub(pa.set[[i]],E.mat)
                E.mat[pa.set[[i]],i] <- -Epa%*%Upa.inver.pai
                Ucond <- U[i,i] - U[i,pa.set[[i]]]%*%Upa.inver.pai
                TT <- Epa%*%(as.numeric(Ucond/(alpha[i]-pa.count[i]-4))*solve(Upa)+Upa.inver.pai%*%t(Upa.inver.pai))
                E.mat[i,i] <- Ucond/(alpha[i]-pa.count[i]-4) + sum(diag(TT))
                if((m-i)-pa.count[i]>0){
                  tmp.non.pa.set <- setdiff((i+1):m,pa.set[[i]])
                  #print(length(tmp.non.pa.set))
                  #print(dim(E.mat[tmp.non.pa.set,pa.set[[i]]]))
                  E.mat[tmp.non.pa.set,i] <- matrix(E.mat[tmp.non.pa.set,pa.set[[i]]],nrow=length(tmp.non.pa.set))%*%as.matrix(solve(Epa,E.mat[pa.set[[i]],i]),ncol=1)
                }
            }
            E.mat[i,(i+1):m] <- E.mat[(i+1):m,i]
        }
    }
    print("End DAGWishart.expect2!")
    return(E.mat)
}


### log of Normalizing constant for DAGWishart distribution (using log for numerical stability)
## Adj: the adjacency matrix of the DAG, with nodes ordered by the parent ordering. That means, i->j implies i>j. This adjacency should be a lower diagnoal 0-1 matrix with all diagonals being zeros.i->j iff A[i,j]==1. Note that the ordering we are using here is different from the original paper, to be compatible with the
## U: parameter of the DAGWishart. Should be an m by m matrix.
## alpha:parameter of the DAGWishar. should be an m-vector

logDAGWishartNorm <- function(Adj, U, alpha){
    m <- nrow(Adj)
    if(m!=ncol(Adj)) stop("Adjacent matrix is not square!")
    pa.set <- apply(Adj,2,function(x){which(x!=0)})
    if(length(pa.set)>0){
        pa.count <- unlist(lapply(pa.set,length))
        if(sum((alpha-2)<=pa.count)>0) stop("The alpha must satisfy alpha_i > pa_i+2!")
        pa.mat <- lapply(pa.set,GetDiagSub,U=U)
        pa.mat.det <- unlist(lapply(pa.mat,SpecialDet))
        fa.set <- lapply(1:m,function(i){return(c(pa.set[[i]],i))})
        fa.mat <- lapply(fa.set,GetDiagSub,U=U)
        fa.mat.det <- unlist(lapply(fa.mat,SpecialDet))
    } else{
        pa.count <- rep(0,m)
        if(sum((alpha-2)<=pa.count)>0) stop("The alpha must satisfy alpha_i > pa_i+2!")
        pa.mat.det <- rep(1,m)
        fa.set <- lapply(1:m, function(i)return(i))
        fa.mat <- lapply(fa.set,GetDiagSub,U=U)
        fa.mat.det <- unlist(lapply(fa.mat,SpecialDet))

    }
    logz <- sum(lgamma(alpha/2-pa.count/2-1) + log(2)*(alpha/2-1) + log(pi)*pa.count/2 + log(pa.mat.det)*(alpha-pa.count-3)/2 - log(fa.mat.det)*(alpha-pa.count-1)/2)
    return(logz)
}


#### logDAGMargScore: the function to compute the log of marginal score given data and the DAG structure. The calculation is based on the normalizing constant ratio as shown in Lemma B.1 in the paper
### x: the data from the DAG Gaussian model. It should be in the format of a n by m matrix where each row is one data point.
### Adj, U and alpha are all identically defined as before.
logDAGMargScore <- function(x,Adj,U,alpha){
    X <- scale(x,center=TRUE,scale=TRUE)
    n <- nrow(X)
    S <- t(X)%*%X
    U.star <- S+U
    alpha.star <- alpha+n
    logPosterior <- logDAGWishartNorm(Adj,U.star,alpha.star)
    logPrior <- logDAGWishartNorm(Adj,U,alpha)
    logScore <- logPosterior-logPrior
    return(logScore)
}



#### SimpleGraphMove: the function to generate new graphs by adding/deleting on edge of the given graph
#### Adj: the adjacency matrix defined as before.
#### n: the number of new graphs to generate
#### checklist: a list of adjacency matrices that one wants to avoid generating. By default NULL

SimpleGraphMove <- function(Adj,n=1,checklist=NULL){
    if(!is.null(checklist)){
            result.list <- list()
            total.edge.index <- which(lower.tri(Adj))
            total.edge.number <- length(total.edge.index)
            if(total.edge.number<(n+length(checklist))) stop(paste("Cannot generate",n,"new graphs!"))
            perm.edge.index <- sample(total.edge.index,size=total.edge.number)
            checklist.edge.list <- lapply(checklist,function(x)return(which(x==1)))
            iter <- 1
            for(k in 1:total.edge.number){
                tmp.Adj <- Adj
                tmp.Adj[perm.edge.index[k]] <- 1-tmp.Adj[perm.edge.index[k]]
                tmp.edge.index <- which(tmp.Adj==1)
                if(sum(unlist(lapply(checklist.edge.list,function(x)return(setequal(x,tmp.edge.index)))))==0)
                {
                    result.list[[iter]] <- tmp.Adj
                    iter <- iter+1
                }
                if(iter>n) break
            }
            return(result.list)
    }
    result.list <- list()
    total.edge.index <- which(lower.tri(Adj))
    total.edge.number <- length(total.edge.index)
    if(total.edge.number<n) stop(paste("Cannot generate",n,"new graphs!"))
    perm.edge.index <- sample(total.edge.index,size=total.edge.number)
    iter <- 1
    for(k in 1:total.edge.number){
        tmp.Adj <- Adj
        tmp.Adj[perm.edge.index[k]] <- 1-tmp.Adj[perm.edge.index[k]]
        result.list[[iter]] <- tmp.Adj
        iter <- iter+1
        if(iter>n) break
    }
    return(result.list)
}



#### SSS : the stochastic shotegun search with DAG Wishart prior. The logic is shown in Jones 2005.
### x, U: defined as before
### Adj0, the starting graph adjacency matrix
### alpha.scale, alpha.b: the vector for alpha in each DAG Wishart prior. If TRUE (default), then the true alpha used in evaluation each graph will be alpha[i]*(pa(i))+b. Note that in this case, alpha[i] must be greater or equal to 1. If FALSE (not recommended), then alpha itself is used for every graph. Note that in this case, alpha has to satisfy that alpha[i] > pa(i)+2 for all the potential DAGs, thus it must be very large, which might undermine the estimation (in a parsimoneous way).
### gamma: the annealing parameter in SSS of Jones 2005. It is set to be 1 by default
### X1, X3 are parameters defined the same as in Jones 2005. X1 is the graphs to explore in each step, X2 is the number of graphs to choose from for new steps (we set X2=X1 as suggested in the paper) and X3 is the number of final retained list.
### stop.num: the stopping rule. If the top X3 list has not been changed in the recent stop.num of iteration, then the algorithm stops.
### iter.max: the maximum number of iterations, if stop.num is not achieved.

SSS <- function(x,Adj0,U,alpha.scale,adaptive=TRUE,gamma=1,X1=1,X3=50,stop.num=20,iter.max=500,alpha.b=3){
    ## basic checking
    #if(X2>X1) stop("X2 cannot be larger than X1!")
    x <- scale(x,TRUE,TRUE)
    if(min(alpha.scale)<1) stop("alpha must be larger than 1!")

    ## object setup
    final.list <- list(Graph=list(),logScore=rep(0,X3),MinIndex=0,Length=0)
    iter.num <- 0
    nochange.num <- 0
    pre.MinScore <- NULL

    ##
    ini.pa.count <- apply(Adj0,2,function(x){return(sum(x==1))})
    ini.alpha <- alpha.scale*ini.pa.count+alpha.b
    ini.score <- logDAGMargScore(x,Adj0,U,ini.alpha)
    final.list$Graph[[1]] <- Adj0
    final.list$logScore[1] <- ini.score
    final.list$MinIndex <- 1
    final.list$Length <- 1
    current.Adj <- Adj0
    pre.MinScore <- ini.score
    DAG.checklist <- final.list$Graph

    while((nochange.num < stop.num) && (iter.num < iter.max)){
            ## Generate new graphs
            if(X3==0) DAG.checklist <- NULL
            tmp.graphs <- SimpleGraphMove(current.Adj,n=X1,checklist = DAG.checklist)
            tmp.score <- unlist(lapply(tmp.graphs,function(Adj){
                #pa.count <- apply(Adj,2,function(x){return(sum(x==1))})
                pa.count <- colSums(Adj)
                alpha <- alpha.scale*pa.count+alpha.b
                score <- logDAGMargScore2(x,Adj,U,alpha)
                return(score)
            }))
            ## update candidate list
            for(k in 1:X1){
                final.list <- UpdateGraphList(final.list,tmp.graphs[[k]],tmp.score[k],max.length=X3)
            }
            DAG.checklist <- final.list$Graph
            ## select the graph to start next search
            new.index <- ScoreSampling(tmp.score,gamma)
            current.Adj <- tmp.graphs[[new.index]]
            iter.num <- iter.num + 1
            current.MinScore <- final.list$logScore[final.list$MinIndex]
            nochange.num <- nochange.num + 1
            if(pre.MinScore != current.MinScore) nochange.num <- 0
            pre.MinScore <- current.MinScore
    }
    final.list$iter <- iter.num
    final.list$nochange <- nochange.num
    return(final.list)
}


########################
#### UpdateGraphList: function to update candidate list according to current evaluation. For internal use only.
### glist: the candidate list to update
### Adj: adjacency matrix to consider
### score: log marginal score of the graph
### max.length: the limit for the list
UpdateGraphList <- function(glist,Adj,score,max.length){
    if(glist$Length <  max.length){
        glist$Graph[[glist$Length+1]] <- Adj
        glist$logScore[glist$Length+1] <- score
        glist$Length <- glist$Length+1
        glist$MinIndex <- which.min(glist$logScore)
        #print("reach")
        return(glist)
    }
    if(glist$logScore[glist$MinIndex]<score){
        glist$Graph[[glist$MinIndex]] <- Adj
        glist$logScore[[glist$MinIndex]] <- score
        glist$MinIndex <- which.min(glist$logScore)
        return(glist)
    }
    return(glist)
}

#### ScoreSampling : internal use - function to sample the index to next graph according to the rule in Jones 2005. Special treatment for numerical stability is used.
### logScore: the sequence of log scores
### beta: annealing parameter

log.sum.exp <- function(x){
    maxx <- max(x)
    return(log(sum(exp(x-maxx)))+maxx)
}

ScoreSampling <- function(logScore,gamma=1){
    lscore.vec <- gamma*logScore
    lscore.vec <- lscore.vec - (min(lscore.vec))
    #lscore.vec <- lscore.vec - (mean(lscore.vec))
    #log.score.sum <- log(sum(exp(lscore.vec)))
    log.score.sum <- log.sum.exp(lscore.vec)
    p.weight <- exp(lscore.vec-log.score.sum)
    p.weight <- p.weight/sum(p.weight)
    select.index <- sample(1:length(logScore),size=1,prob=p.weight)
    return(select.index)
}



#### AdjTransform: function to transform between two different DAG adjacent representation. Note that in Ali etc 2010, the natural ordering is defined as i->j implying i<j, but in this paper, the ordering is defined as i-> implying i>j. Also, the adjacency matrix output from Ali etc 2010 takes a_ij =1 iff j->i, but in this paper, we use a_ij=1 iff i->j. These are trivial differences and one can easily change the notations to connect them seamlessly. However, the make the implementation of the methods clear and matches the papers perfectly, the same notations and conventions as in correponding papaers are used for the functions. But to connect them togther, we use this function AdjTransform, which just do the transformation as a_ij -> a_(m+1-j)(m+1-i)

#### Orig.Adj: the Adj represent in the original form
AdjTransform <- function(Orig.Adj){
    m <- nrow(Orig.Adj)
    if(m != ncol(Orig.Adj)) stop("The adjacent matrix has to be square!")
    indx <- 1:m^2
    result.Adj <- mid.Adj <- t(Orig.Adj)
    result.Adj[m^2+1-indx] <- mid.Adj[indx]
    return(result.Adj)
}



#### Evaluation: function to calculate Matthews Correlation Coefficient , Structural Hamming Distance, precision and recall.
### graph1: the true DAG model in "igraph" class
### graph2: the candidate DAG model in "igraph" class
Evaluation <- function(graph1, graph2){
    Adj1 <- as.matrix(get.adjacency(graph1))
    Adj2 <- as.matrix(get.adjacency(graph2))
    true.index <- which(Adj1==1)
    false.index <- setdiff(which(upper.tri(Adj1)),true.index)
    positive.index <- which(Adj2==1)
    negative.index <- setdiff(which(upper.tri(Adj2)),positive.index)

    TP <- length(intersect(true.index,positive.index))
    FP <- length(intersect(false.index,positive.index))
    FN <- length(intersect(true.index,negative.index))
    TN <- length(intersect(false.index,negative.index))

    MCC.denom <- sqrt(TP+FP)*sqrt(TP+FN)*sqrt(TN+FP)*sqrt(TN+FN)
    if(MCC.denom==0) MCC.denom <- 1
    MCC <- (TP*TN-FP*FN)/MCC.denom
    if((TN+FP)==0) MCC <- 1

    Precision <- TP/(TP+FP)
    if((TP+FP)==0) Precision <- 1
    Recall <- TP/(TP+FN)
    if((TP+FN)==0) Recall <- 1
    Sensitivity <- Recall
    Specific <- TN/(TN+FP)
    if((TN+FP)==0) Specific <- 1

    graph1.graph <- igraph.to.graphNEL(graph1)
    graph2.graph <- igraph.to.graphNEL(graph2)
    SHD <- shd(graph1.graph,graph2.graph)
    return(list(Precision=Precision,Recall=Recall,Sensitivity=Sensitivity,Specific=Specific,MCC=MCC,SHD=SHD,TP=TP,FP=FP,TN=TN,FN=FN))
}

#### DAGWishartSelection: function to combine penalized likelihood and DAGWishart SSS
DAGWishartSelection <- function(x,typeIp=seq(0.05,0.2,by=0.05),U,alpha.scale,adaptive=TRUE,gamma=1,X1=1,X3=50,stop.num=20,iter.max=500,standardize=TRUE,alpha.b=3,gm=1){
    n <- nrow(x)
    p <- ncol(x)
    M <- length(typeIp)
    x <- scale(x,center=TRUE,scale=TRUE)
    S <- cor(x)
    all.models <- list(LassoDAG=list(),WishartDAG=list(),logScore=rep(0,M),LassoSigma = list(),WishartSigma=list(),WishartMAP=list())
    for(k in 1:M){
        print(paste("Begin simulation ",k,"...",sep=""))
        P <- typeIp[k]
        lambdas <- c(1,2*qnorm(p=(P/(2*p*(1:(p-1)))),lower.tail=FALSE))/sqrt(n)
        #lambdas <- c(1,rep(2*qnorm(p=(1-P/(2*p))),p-1))/sqrt(n)
        LassoAdj <- DAGLasso(x=x,lambda.seq=lambdas,adaptive=adaptive)
        print("Finish LassoDAG...")
        LassoAdj[which(LassoAdj!=0)] <- 1
        Adj <- AdjTransform(LassoAdj)
        LassoS <- DAG.MLE(S[p:1,p:1],Adj)
        LassoS <- LassoS[p:1,p:1]
        StepList <- SSS(x[,p:1],Adj0=Adj,U=U,alpha.scale=alpha.scale,stop.num=stop.num,X3=X3,iter.max=iter.max,X1=X1,alpha.b=alpha.b,gamma=gm)
        print("Finish LaSDAW ...")
        WishartAdj <- StepList$Graph[[which.max(StepList$logScore)]]
        WishartSigma <- DAG.MLE(S[p:1,p:1],WishartAdj)
        WishartMAP <- DAG.MAP(S[p:1,p:1],WishartAdj,U,alpha.scale,alpha.b,n)
        WishartAdj <- AdjTransform(WishartAdj)
        all.models$LassoDAG[[k]] <- graph.adjacency(t(LassoAdj),mode="directed",weighted=TRUE,diag=FALSE)
        all.models$WishartDAG[[k]] <- graph.adjacency(t(WishartAdj),mode="directed",weighted=TRUE,diag=FALSE)
        all.models$logScore[k] <- max(StepList$logScore)
        all.models$LassoSigma[[k]] <- LassoS
        all.models$WishartSigma[[k]] <- WishartSigma[p:1,p:1]
        all.models$WishartMAP[[k]] <- WishartMAP[p:1,p:1]
    }
    return(all.models)
}




logDAGMargScore2 <- function(x,Adj,U,alpha){
    #X <- scale(x,TRUE,TRUE)
    n <- nrow(x)
    p <- ncol(x)
    S <- t(x)%*%x
    U.star <- S+U
    alpha.star <- alpha+n
    pa.set <- apply(Adj,2,function(x){which(x!=0)})
    logPosterior <- logDAGWishartNorm2(pa.set,p,U.star,alpha.star)
    logPrior <- logDAGWishartNorm2(pa.set,p,U,alpha)
    logScore <- logPosterior-logPrior
    return(logScore)
}


logDAGWishartNorm2 <- function(pa.set, m, U, alpha){
    #m <- nrow(Adj)
    #if(m!=ncol(Adj)) stop("Adjacent matrix is not square!")
    #pa.set <- apply(Adj,2,function(x){which(x!=0)})
    if(length(pa.set)>0){
        pa.count <- unlist(lapply(pa.set,length))
        if(sum((alpha-2)<=pa.count)>0) stop("The alpha must satisfy alpha_i > pa_i+2!")
        pa.mat <- lapply(pa.set,GetDiagSub,U=U)
        pa.mat.det <- unlist(lapply(pa.mat,SpecialDet))
        fa.set <- lapply(1:m,function(i){return(c(pa.set[[i]],i))})
        fa.mat <- lapply(fa.set,GetDiagSub,U=U)
        fa.mat.det <- unlist(lapply(fa.mat,SpecialDet))
    } else{
        pa.count <- rep(0,m)
        if(sum((alpha-2)<=pa.count)>0) stop("The alpha must satisfy alpha_i > pa_i+2!")
        pa.mat.det <- rep(1,m)
        fa.set <- lapply(1:m, function(i)return(i))
        fa.mat <- lapply(fa.set,GetDiagSub,U=U)
        fa.mat.det <- unlist(lapply(fa.mat,SpecialDet))

    }
    logz <- sum(lgamma(alpha/2-pa.count/2-1) + log(2)*(alpha/2-1) + log(pi)*pa.count/2 + log(pa.mat.det)*(alpha-pa.count-3)/2 - log(fa.mat.det)*(alpha-pa.count-1)/2)
    return(logz)
}





GetTrueSigma <- function(DAG,sim=FALSE){
    #print("Call GetTrueSigma!")
    if(sim){
	GraphX <- rmvDAG(n=200000,dag=DAG,errDist="normal",mix=0)

	#x<- scale(GraphX,TRUE,TRUE)

	#Sigma <- t(x)%*%x/(200000-1)
        Sigma <- cor(GraphX)
	#tt.svd <- svd(Sigma)
	#print(sum(tt.svd$d>0))
	#print(min(tt.svd$d))
	#print("End GetTrueSigma!")
	return(Sigma)
    }
    TC <- trueCov(DAG)
    Sigma <- diag(1/sqrt(diag(TC)))%*%TC%*%diag(1/sqrt(diag(TC)))
    #print("End GetTrueSigma!")
    return(as.matrix(Sigma))
}

SteinLoss <- function(trueSigma,Sigma,p,decomp=TRUE){
        #print("Call Stein's Loss!")
	#block <- solve(trueSigma+diag(rep(0.01,p)),Sigma)
        #if(p>=500){
	 #  block <- solve(trueSigma+diag(rep(0.01,p)),Sigma)
          # ss <- svd(block)
	   #L <- sum(diag(block)) - sum(log(ss$d)) - p
        #}else{
           if(decomp){
           SVD <- svd(trueSigma)
           SS <- t(SVD$u)%*%Sigma%*%SVD$v
           Cl <- chol(Sigma)
           term1 <- sum(diag(SS)/SVD$d)
           term2 <- -sum(log(SVD$d)) + 2*sum(log(diag(Cl)))
           L <- term1 - term2 - p
           return(L)
           }
       	   block <- solve(trueSigma,Sigma)
           ss <- svd(block)
           SVD <- svd(trueSigma)
           SS <- t(SVD$u)%*%Sigma%*%SVD$v
           term1 <- 
	   L <- sum(diag(block)) - sum(log(ss$d)) - p
           #L <- sum(diag(block)) - log(det(block)) - p
        #}
        #print("End Stein's Loss!")
	return(L)
}


SquareLoss <- function(trueSigma,Sigma,Adj){
	DifMat2 <- (trueSigma - Sigma)^2
	return(sum((DifMat2[which(Adj != 0)])))
}


E.Prec <- function(alpha,U,Adj){
    m <- nrow(Adj)
    if((m!=ncol(Adj))||(m!=length(alpha))) stop("Dimension Incorrect!")
    pa.set <- apply(Adj,2,function(x){which(x!=0)})
    if(length(pa.set)>0){    
	    pa.count <- unlist(lapply(pa.set,length))
		Gm <- matrix(NA,nrow=m,ncol=m)
		RU <- matrix(0,nrow=m,ncol=m)
		for(j in 1:m){
			pa.self <- c(j,pa.set[[j]])
			U.pa.self <- GetDiagSub(pa.self,U)
			tmp.U2 <- tmp.U1 <- matrix(0,m,m)
			tmp.U1[pa.self,pa.self] <- (alpha[j]-pa.count[j]-2)*solve(U.pa.self)
			
			if(pa.count[j]>0){
				tmp.U2[pa.set[[j]],pa.set[[j]]] <- (alpha[j]-pa.count[j]-3)*solve(GetDiagSub(pa.set[[j]],U))
				
			} 
			RU <- RU + tmp.U1 - tmp.U2
		}
		for(j in 1:m){
			if(pa.count[j]>0){
				Gm[pa.set[[j]],j] <- RU[pa.set[[j]],j]
				Gm[j,pa.set[[j]]] <- Gm[pa.set[[j]],j]
			}
		}
		diag(Gm) <- diag(RU)
	}else{
		Gm <- matrix(0,nrow=m,ncol=m)
		diag(Gm) <- (alpha-2)/diag(U)
		return(Gm)
	}
	Lambda <- L <- matrix(0,m,m)
	diag(L) <- 1
	Lambda[1,1] <- Gm[1,1]
	if(pa.count[1]>0){
		for(i in pa.set[[1]]){
			L[i,1] <- Gm[i,1]/Lambda[1,1]
		}
	}
	for(j in 2:m){
		Lambda[j,j] <- Gm[j,j] - sum((diag(Lambda)*L[j,]^2)[1:(j-1)])
		if(pa.count[j]>0){
			for(i in pa.set[[j]]){
				L[i,j] <- (Gm[i,j] - sum((diag(Lambda)*L[i,]*L[j,])[1:(j-1)]))/Lambda[j,j]
			}
		}
	}
	return(L%*%(Lambda)%*%t(L))
}




E.Sigma <- function(alpha,U,Adj){
    m <- nrow(Adj)
    if((m!=ncol(Adj))||(m!=length(alpha))) stop("Dimension Incorrect!")
    pa.set <- apply(Adj,2,function(x){which(x!=0)})
    Sigma <- matrix(0,m,m)
    if(length(pa.set)==0){
    	  diag(Sigma) <- diag(U)/(alpha-4)
    	  return(Sigma)
    }
    pa.count <- unlist(lapply(pa.set,length))
    Sigma[m,m] <- U[m,m]/(alpha[m]-4)
	for(i in seq((m-1),1,by=-1)){
		if(pa.count[i]==0){
			Sigma[i,i] <- U[i,i]/(alpha[i]-4)
			Sigma[i,((i+1):m)] <- Sigma[((i+1):m),i] <- 0
		}else{
			block <- solve(matrix(GetDiagSub(pa.set[[i]],U),ncol=pa.count[i]),matrix(U[pa.set[[i]],i],ncol=1))
			Sigma[pa.set[[i]],i] <- matrix(GetDiagSub(pa.set[[i]],Sigma),ncol=pa.count[i]) %*% block
			cond.U.pa <- as.numeric(U[i,i]-matrix(U[i,pa.set[[i]]],nrow=1)%*%block)
			tmp.inner <- matrix(Sigma[pa.set[[i]],i],ncol=1)%*%t(block) + cond.U.pa*t(solve(matrix(GetDiagSub(pa.set[[i]],U),ncol=pa.count[i]),matrix(GetDiagSub(pa.set[[i]],Sigma),ncol=pa.count[i])))/(alpha[i]-pa.count[i]-4)
			Sigma[i,i] <- cond.U.pa/(alpha[i]-pa.count[i]-4) + sum(diag(tmp.inner))
			if(pa.count[i]<(m-i)){
				non.pa <- setdiff(seq((i+1),m),pa.set[[i]])
				Sigma[non.pa,i] <- matrix(Sigma[non.pa,pa.set[[i]]],ncol=pa.count[i]) %*% solve(matrix(GetDiagSub(pa.set[[i]],Sigma),ncol=pa.count[i]),matrix(Sigma[pa.set[[i]],i],ncol=1))
			}
			Sigma[i,((i+1):m)] <- Sigma[((i+1):m),i]
		}
	}
	return(Sigma)
}




get.identity.u <- function(alpha,Adj,t=1){
    m <- nrow(Adj)
    if((m!=ncol(Adj))||(m!=length(alpha))) stop("Dimension Incorrect!")
    pa.set <- apply(Adj,2,function(x){which(x!=0)})
    U <- matrix(0,m,m)
    if(length(pa.set)==0){
    	  diag(Sigma) <- diag(U)/(alpha-4)
    	  return(Sigma)
    }
    pa.count <- unlist(lapply(pa.set,length))
    for(k in m:1){
    	if(pa.count[k]==0){
    		U[k,k] <- alpha[k]-4
    	}else{
    		U[k,k] <- (alpha[k]-pa.count[k]-4)/(1+sum(1/(diag(U)[pa.set[[k]]])))
    	}
    }
	return(t*U)
}
