library(pcalg)
library(Rgraphviz)
library(igraph)
source("functions.R")
source("multGG.R")
source("PerfEval.R")
library(ggplot2)
library(plyr)

x <- read.table("../../Data/CallCenter2002/call-center-data.txt",header=F,sep=" ")

x <- sqrt(x+0.25)
p <- 102
train <- x[1:205,]
test <- x[206:239,]

CC.cov <- var(x[,p:1])
save(CC.cov,file="CallCenterCovariance.Rda")
x <- scale(train,TRUE,TRUE)

p <- ncol(x)
n <- nrow(x)
U <- diag(rep(1,p))
alpha.scale <- rep(1,p)
source("functions.R")
system.time(Test2 <- DAGWishartSelection(x=x,typeIp=c(0.1,(seq(1:10)/10)^4*p),U=U,alpha.scale=alpha.scale,stop.num=20,X3=0,iter.max=200,X1=30,gm=1))

save(Test2,file="CallCenterModels-Final.Rda")


load("../CallCenterModels-Final.Rda")

best.Wishart <- which.max(Test2$logScore)
Lasso.estimate <- Test2$LassoDAG[[1]]
DAGWishart.estimate <- Test2$WishartDAG[[best.Wishart]]

WishartAdj <- AdjTransform(t(get.adjacency(DAGWishart.estimate)))





LassoSigma <- Test2$LassoSigma[[1]]#[p:1,p:1]
WishartSigma <- Test2$WishartSigma[[best.Wishart]]#[p:1,p:1]
WishartMAP <- Test2$WishartMAP[[best.Wishart]]#[p:1,p:1]






scales <- apply(train,2,sd)
LL <- t(t(LassoSigma*scales)*scales)
WW <- t(t(WishartSigma*scales)*scales)
MM <- t(t(WishartMAP*scales)*scales)

SS <- var(train)


mu <- colMeans(train)


pa.set <- apply(WishartAdj,2,function(x){which(x!=0)})
Alpha <- rep(3,p)
if(length(pa.set)>0){
        pa.count <- unlist(lapply(pa.set,length))
        Alpha <- Alpha + alpha.scale*pa.count
}
Alpha <- Alpha + n
tmp.U <- U + n*var(x)[p:1,p:1]

RR <- E.Prec(Alpha,tmp.U,WishartAdj)
RR <- RR[p:1,p:1]
RR <- solve(RR)
RR <- diag(scales)%*%RR%*%diag(scales)


CC <- E.Sigma(Alpha,tmp.U,WishartAdj)
CC <- CC[p:1,p:1]
CC <- diag(scales)%*%CC%*%diag(scales)


predict.half <- function(x1,mu,Sigma){
    p1 <- length(x1)
    p <- length(mu)
    p2 <- p-p1
    mu1 <- mu[1:p1]
    mu2 <- mu[(p1+1):p]
    Sigma11 <- Sigma[1:p1,1:p1]
    #Sigma12 <- Sigma[1:p1,(p1+1):p]
    Sigma21 <- Sigma[(p1+1):p,1:p1]
    #Sigma22 <- Sigma[(p1+1):p,(p1+1):p]
    x2 <- mu2 + Sigma21%*%solve(Sigma11,x1-mu1)
    return(x2)
}
M.estimate <- colMeans(train[,52:102])
CovError <- PrecError <- RegressError <- NaiveError <- MeanError <- WishartError <- LassoError <- MAPError <- matrix(0,nrow=nrow(test),ncol=51)
for(k in 1:nrow(test)){
    L.mu2 <- predict.half(test[k,1:51],mu=mu,Sigma=LL)
    W.mu2 <- predict.half(test[k,1:51],mu=mu,Sigma=WW)
    N.mu2 <- predict.half(test[k,1:51],mu=mu,Sigma=SS)
    M.mu2 <- predict.half(test[k,1:51],mu=mu,Sigma=MM)
    R.mu2 <- predict.half(test[k,1:51],mu=mu,Sigma=RR)
    C.mu2 <- predict.half(test[k,1:51],mu=mu,Sigma=CC)
    LassoError[k,] <- (L.mu2-as.numeric(test[k,52:102]))
    WishartError[k,] <- (W.mu2-as.numeric(test[k,52:102]))
    MeanError[k,] <- (M.estimate-as.numeric(test[k,52:102]))
    NaiveError[k,] <- (N.mu2-as.numeric(test[k,52:102]))
    MAPError[k,] <- (M.mu2-as.numeric(test[k,52:102]))
    PrecError[k,] <- (R.mu2-as.numeric(test[k,52:102]))
    CovError[k,] <- (C.mu2-as.numeric(test[k,52:102]))
}



E.lasso <- colMeans(abs(LassoError))
E.wishart <- colMeans(abs(WishartError))
E.mean <- colMeans(abs(MeanError))
E.naive <- colMeans(abs(NaiveError))
E.map <- colMeans(abs(MAPError))
E.map50 <- E.map
E.prec <- colMeans(abs(PrecError))
E.cov <- colMeans(abs(CovError))

pdf("../Figures/CallCenterError-2002-Final.pdf",height=6,width=8)
plot(rep(52:102,4),c(E.lasso,E.wishart,E.mean,E.naive),type="n",col="red",lty=1,lwd=2,main="Average Absolute Estimation Error",ylab="Error",xlab="Time point")
lines(52:102,E.lasso,col="red",lty=2,lwd=2)
lines(52:102,E.wishart,col="blue",lty=1,lwd=2)

lines(52:102,E.prec,col="purple",lty=4,lwd=2)
lines(52:102,E.naive,col="green",lty=5,lwd=2)
#lines(52:102,E.map,col="yellow",lty=6,lwd=2)
#lines(1:51,E.mean,col="yellow",lty=6,lwd=2)
legend("topright",legend=c("LassoDAG-MLE","DAG-W-MLE","DAG-W-Precision","Naive-MLE"),col=c("red","blue","purple","green"),lty=c(2,1,4,5),lwd=rep(2,4))
dev.off()

lasso.norm <- rowSums((LassoError)^2)
wishart.norm <- rowSums((WishartError)^2)
mean.norm <- rowSums((MeanError)^2)
mle.norm <- rowSums((NaiveError)^2)
map.norm <- rowSums((MAPError)^2)
prec.norm <- rowSums((PrecError)^2)

dd <- data.frame(LassoDAG = mean(lasso.norm),LaSDAW.MLE = mean(wishart.norm),LaSDAW.MAP=mean(map.norm),MLE=mean(mle.norm),Precision=mean(prec.norm))
rownames(dd) <- "MSE"
library(xtable)
xtable(dd,caption="Mean squared errors of predictions given by different methods.",label="CallCenterMSE",digits=3)

