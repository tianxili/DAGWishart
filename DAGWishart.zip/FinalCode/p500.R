rm(list=ls())
require(doParallel)
#cl <- makeCluster(4)
#registerDoParallel(cl)
#trials <- 100
#ptime <- system.time(
# {
 # r <- foreach(icount(trials)) %dopar% {
  # tt <- rnorm(1)
  #}
 #}
#)

registerDoParallel(cores=15)


r <- foreach(i=1:15) %dopar%{
source("EstEval.R") 
m <- 20
sss = 101


r1 <- EstimationEvaluation(M=m,p=500,n=30,sparsity=0.01,strength=0.5,u=3,alpha=2.5,b=3,seed=sss+i,ident=F,t=3)
r2 <- EstimationEvaluation(M=m,p=500,n=50,sparsity=0.01,strength=0.5,u=3,alpha=2.5,b=3,seed=sss+i,ident=F,t=3)
r3 <- EstimationEvaluation(M=m,p=500,n=100,sparsity=0.01,strength=0.5,u=3,alpha=2.5,b=3,seed=sss+i,ident=F,t=3)

r4 <- EstimationEvaluation(M=m,p=500,n=30,sparsity=0.01,strength=0.5,u=3,alpha=3,b=3,seed=sss+i,ident=F,t=3)
r5 <- EstimationEvaluation(M=m,p=500,n=50,sparsity=0.01,strength=0.5,u=3,alpha=3,b=3,seed=sss+i,ident=F,t=3)
r6 <- EstimationEvaluation(M=m,p=500,n=100,sparsity=0.01,strength=0.5,u=3,alpha=3,b=3,seed=sss+i,ident=F,t=3)

r7 <- EstimationEvaluation(M=m,p=500,n=30,sparsity=0.01,strength=0.5,u=3,alpha=3.5,b=3,seed=sss+i,ident=F,t=3)
r8 <- EstimationEvaluation(M=m,p=500,n=50,sparsity=0.01,strength=0.5,u=3,alpha=3.5,b=3,seed=sss+i,ident=F,t=3)
r9 <- EstimationEvaluation(M=m,p=500,n=100,sparsity=0.01,strength=0.5,u=3,alpha=3.5,b=3,seed=sss+i,ident=F,t=3)


r10 <- EstimationEvaluation(M=m,p=500,n=30,sparsity=0.01,strength=0.5,u=2.5,alpha=3,b=3,seed=sss+i,ident=F)
r11 <- EstimationEvaluation(M=m,p=500,n=50,sparsity=0.01,strength=0.5,u=2.5,alpha=3,b=3,seed=sss+i,ident=F)
r12 <- EstimationEvaluation(M=m,p=500,n=100,sparsity=0.01,strength=0.5,u=2.5,alpha=3,b=3,seed=sss+i,ident=F)


r13 <- EstimationEvaluation(M=m,p=500,n=30,sparsity=0.01,strength=0.5,u=3.5,alpha=3,b=3,seed=sss+i,ident=F)
r14 <- EstimationEvaluation(M=m,p=500,n=50,sparsity=0.01,strength=0.5,u=3.5,alpha=3,b=3,seed=sss+i,ident=F)
r15 <- EstimationEvaluation(M=m,p=500,n=100,sparsity=0.01,strength=0.5,u=3.5,alpha=3,b=3,seed=sss+i,ident=F)


rbind(r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12,r13,r14,r15)

}

save(r,file="p500-BetterEstimation-Full.Rda")







