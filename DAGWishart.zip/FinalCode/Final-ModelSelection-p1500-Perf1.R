rm(list=ls())
require(doParallel)
#cl <- makeCluster(4)
#registerDoParallel(cl)
#trials <- 100
#ptime <- system.time(
# {
 # r <- foreach(icount(trials)) %dopar% {
  # tt <- rnorm(1)
  #}
 #}
#)

registerDoParallel(cores=10)
alpha.seq <- c(1,seq(10,60,by=10))
r <- foreach(i=1:10) %dopar%{
source("PerfEval2.R") 

PerformanceEvaluation(M=2,p=1500,n=100,sparsity=0.01,strength=0.5,u=1,alpha=1,b=3,seed=500*i+91,X1=30,X3=0,iter=100,LassoNum=2,gm=0.5)

}

EvalSum <- NULL
for(k in 1:length(r)) EvalSum <- rbind(EvalSum,r[[k]]$Eval)
save(EvalSum,file="Final-ModelSelection-p1500-Single-Part1.Rda")







