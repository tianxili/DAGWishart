rm(list=ls())
require(doParallel)
#cl <- makeCluster(4)
#registerDoParallel(cl)
#trials <- 100
#ptime <- system.time(
# {
 # r <- foreach(icount(trials)) %dopar% {
  # tt <- rnorm(1)
  #}
 #}
#)

registerDoParallel(cores=15)


r <- foreach(i=1:15) %dopar%{
source("EstEval.R") 
m <- 20
sss = 101


r1 <- EstimationEvaluation(M=m,p=500,n=30,sparsity=0.01,strength=0.5,u=3,alpha=3,b=3,seed=sss+i,ident=F,t=3,mix=0.01)
r2 <- EstimationEvaluation(M=m,p=500,n=50,sparsity=0.01,strength=0.5,u=3,alpha=3,b=3,seed=sss+i,ident=F,t=3,mix=0.01)
r3 <- EstimationEvaluation(M=m,p=500,n=100,sparsity=0.01,strength=0.5,u=3,alpha=3,b=3,seed=sss+i,ident=F,t=3,mix=0.01)

rbind(r1,r2,r3)

}

save(r,file="p500-BetterEstimation-mix-N100.Rda")







