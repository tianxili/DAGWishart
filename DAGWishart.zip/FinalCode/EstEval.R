EstimationEvaluation <- function(M=10,p,n,sparsity,strength,u=1,alpha=1,b=3,seed=500,ident=FALSE,t=1,mix=0){
library(pcalg)
library(Rgraphviz)
library(igraph)
library(plyr)
source("../Code/functions.R")

#### We will divide the study in two parts. In the first one, we will test the model on simulated data from three different perspectives: A) the edge connection strength; B) the sparsity and C) the dimensionality p.

u.seq <- Obj.seq <- Stein.seq <- Frob.seq <- Eval.alpha <- Eval.b <- Eval.n <- Eval.p <- Eval.sparsity <- Eval.strength <- Eval.model <- Eval.mcc <- Eval.shd <- NULL
trueMatrix.List <- Matrix.List <- list()

    #sparsity <- sparsity.seq
##theta is the probability that nodes with higher ordering will be connected to each node of lower order
    minw <- strength-0.3
    maxw <- strength+0.3
    ## min rho and max rho are the bound for direct effects of a parement node to one of its child node
    DAG.list <- GraphX.list <- list()
    set.seed(seed)
    for(k in 1: M){
    DAG.list[[k]] <- randomDAG(n=p,prob=sparsity,lB=minw,uB=maxw)
    if(mix==0) {GraphX.list[[k]] <- rmvDAG(n=n,dag=DAG.list[[k]],errDist="normal",mix=mix)}else{
       GraphX.list[[k]] <- rmvDAG(n=n,dag=DAG.list[[k]],errDist="mixN100",mix=mix) 
    }
    }
    U <- diag(rep(u,p))
    alpha.scale <- rep(alpha,p)

    for(k in 1:M){
        GraphX <- GraphX.list[[k]]
        DAG <- DAG.list[[k]]
        #tmp.U <- U

        true.DAG <- igraph.from.graphNEL(DAG)
        trueSigma <- GetTrueSigma(DAG)
        Adj <- get.adjacency(true.DAG)
        WishartAdj <- t(AdjTransform(Adj))
        x <- scale(GraphX,TRUE,TRUE)
        scales <- apply(GraphX,2,sd)
        S <- t(x)%*%x/n
        squareAdj <- WishartAdj
        diag(squareAdj) <- 1
 


        
        trueSigma <- trueSigma[p:1,p:1]
        truePrec <- solve(trueSigma)
        
        MLE.Cov <- DAG.MLE(S[p:1,p:1],WishartAdj)        
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"MLE")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MLE.Cov <- SquareLoss(trueSigma,MLE.Cov,squareAdj)#norm(trueSigma-MLE.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MLE.Cov)
        Stein.MLE.Cov <- SteinLoss(trueSigma,MLE.Cov,p)
        Stein.seq <- c(Stein.seq,Stein.MLE.Cov)
        #Matrix.List <- c(Matrix.List,MLE.Cov)
        #trueMatrix.List <- c(trueMatrix.List,trueSigma)

        MLE.Prec <- solve(MLE.Cov)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"MLE")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MLE.Prec <- SquareLoss(truePrec,MLE.Prec,squareAdj)#norm(truePrec-MLE.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MLE.Prec)
        Stein.MLE.Prec <- SteinLoss(truePrec,MLE.Prec,p)
        Stein.seq <- c(Stein.seq,Stein.MLE.Prec)
        #Matrix.List <- c(Matrix.List,MLE.Prec)
        #trueMatrix.List <- c(trueMatrix.List,truePrec)


#### Evaluate estimation given by DAG Wishart posterior expectation
        pa.set <- apply(WishartAdj,2,function(x){which(x!=0)})
        Alpha <- rep(b,p)
        if(length(pa.set)>0){
        	pa.count <- unlist(lapply(pa.set,length))
        	Alpha <- Alpha + alpha.scale*pa.count
        }
        Alpha <- Alpha + n
        tmp.U <- U + n*S[p:1,p:1]
      
        
        Post.E.Cov <- E.Sigma(alpha=Alpha,U=tmp.U,Adj=WishartAdj)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"WishartExpect")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Cov <- SquareLoss(trueSigma,Post.E.Cov,squareAdj)#norm(trueSigma-Post.E.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Cov)
        Stein.Post.E.Cov <- SteinLoss(trueSigma,Post.E.Cov,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Cov)
        #Matrix.List <- c(Matrix.List,Post.E.Cov)
        #trueMatrix.List <- c(trueMatrix.List,trueSigma)

        Post.E.Cov.inv <- solve(Post.E.Cov)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"Wishart.Cov.inverse")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Cov.inv <- SquareLoss(truePrec,Post.E.Cov.inv,squareAdj)#norm(trueSigma-Post.E.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Cov.inv)
        Stein.Post.E.Cov.inv <- SteinLoss(truePrec,Post.E.Cov.inv,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Cov.inv)
        

        Post.E.Prec <- E.Prec(alpha=Alpha,U=tmp.U,Adj=WishartAdj)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"WishartExpect")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Prec <- SquareLoss(truePrec,Post.E.Prec,squareAdj)#norm(truePrec-Post.E.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Prec)
        Stein.Post.E.Prec <- SteinLoss(truePrec,Post.E.Prec,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Prec)
        #Matrix.List <- c(Matrix.List,Post.E.Prec)
        #trueMatrix.List <- c(trueMatrix.List,truePrec)


        Post.E.Prec.inv <- solve(Post.E.Prec)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"Wishart.Prec.inverse")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Prec.inv <- SquareLoss(trueSigma,Post.E.Prec.inv,squareAdj)#norm(truePrec-Post.E.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Prec.inv)
        Stein.Post.E.Prec.inv <- SteinLoss(trueSigma,Post.E.Prec.inv,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Prec.inv)




#### MAP estimators

        MAP.Cov <- DAG.MAP(S[p:1,p:1],Adj=WishartAdj,U=U,alpha.c=alpha,alpha.b=b,n=n)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"MAP")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MAP.Cov <- SquareLoss(trueSigma,MAP.Cov,squareAdj)#norm(trueSigma-MAP.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MAP.Cov)
        Stein.MAP.Cov <- SteinLoss(trueSigma,MAP.Cov,p)
        Stein.seq <- c(Stein.seq,Stein.MAP.Cov)
        #Matrix.List <- c(Matrix.List,MAP.Cov)
        #trueMatrix.List <- c(trueMatrix.List,trueSigma)
        
        MAP.Prec <- solve(MAP.Cov)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"MAP")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MAP.Prec <- SquareLoss(truePrec,MAP.Prec,squareAdj)#norm(truePrec-MAP.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MAP.Prec)
        Stein.MAP.Prec <- SteinLoss(truePrec,MAP.Prec,p)
        Stein.seq <- c(Stein.seq,Stein.MAP.Prec)
        #Matrix.List <- c(Matrix.List,MAP.Prec)
        #trueMatrix.List <- c(trueMatrix.List,truePrec)
          
    }


    if(ident){
    for(k in 1:M){
        GraphX <- GraphX.list[[k]]
        DAG <- DAG.list[[k]]
        #tmp.U <- U

        true.DAG <- igraph.from.graphNEL(DAG)
        trueSigma <- GetTrueSigma(DAG)
        Adj <- get.adjacency(true.DAG)
        WishartAdj <- t(AdjTransform(Adj))
        x <- scale(GraphX,TRUE,TRUE)
        scales <- apply(GraphX,2,sd)
        S <- t(x)%*%x/n
        squareAdj <- WishartAdj
        diag(squareAdj) <- 1
 
        
        trueSigma <- trueSigma[p:1,p:1]
        truePrec <- solve(trueSigma)
        
        MLE.Cov <- DAG.MLE(S[p:1,p:1],WishartAdj)        
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"MLE")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,-t)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MLE.Cov <- SquareLoss(trueSigma,MLE.Cov,squareAdj)#norm(trueSigma-MLE.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MLE.Cov)
        Stein.MLE.Cov <- SteinLoss(trueSigma,MLE.Cov,p)
        Stein.seq <- c(Stein.seq,Stein.MLE.Cov)
        #Matrix.List <- c(Matrix.List,MLE.Cov)
        #trueMatrix.List <- c(trueMatrix.List,trueSigma)

        MLE.Prec <- solve(MLE.Cov)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"MLE")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,-t)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MLE.Prec <- SquareLoss(truePrec,MLE.Prec,squareAdj)#norm(truePrec-MLE.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MLE.Prec)
        Stein.MLE.Prec <- SteinLoss(truePrec,MLE.Prec,p)
        Stein.seq <- c(Stein.seq,Stein.MLE.Prec)
        #Matrix.List <- c(Matrix.List,MLE.Prec)
        #trueMatrix.List <- c(trueMatrix.List,truePrec)


#### Evaluate estimation given by DAG Wishart posterior expectation
        pa.set <- apply(WishartAdj,2,function(x){which(x!=0)})
        Alpha <- rep(b,p)
        if(length(pa.set)>0){
        	pa.count <- unlist(lapply(pa.set,length))
        	Alpha <- Alpha + alpha.scale*pa.count
        }
        u <- -1
        U <- get.identity.u(alpha=Alpha,Adj=WishartAdj,t=t)

        Alpha <- Alpha + n
        tmp.U <- U + n*S[p:1,p:1]
      
        
        Post.E.Cov <- E.Sigma(alpha=Alpha,U=tmp.U,Adj=WishartAdj)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"WishartExpect")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,-t)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Cov <- SquareLoss(trueSigma,Post.E.Cov,squareAdj)#norm(trueSigma-Post.E.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Cov)
        Stein.Post.E.Cov <- SteinLoss(trueSigma,Post.E.Cov,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Cov)
        #Matrix.List <- c(Matrix.List,Post.E.Cov)
        #trueMatrix.List <- c(trueMatrix.List,trueSigma)

        Post.E.Cov.inv <- solve(Post.E.Cov)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"Wishart.Cov.inverse")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,-t)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Cov.inv <- SquareLoss(truePrec,Post.E.Cov.inv,squareAdj)#norm(trueSigma-Post.E.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Cov.inv)
        Stein.Post.E.Cov.inv <- SteinLoss(truePrec,Post.E.Cov.inv,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Cov.inv)
        

        Post.E.Prec <- E.Prec(alpha=Alpha,U=tmp.U,Adj=WishartAdj)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"WishartExpect")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,-t)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Prec <- SquareLoss(truePrec,Post.E.Prec,squareAdj)#norm(truePrec-Post.E.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Prec)
        Stein.Post.E.Prec <- SteinLoss(truePrec,Post.E.Prec,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Prec)
        #Matrix.List <- c(Matrix.List,Post.E.Prec)
        #trueMatrix.List <- c(trueMatrix.List,truePrec)

        Post.E.Prec.inv <- solve(Post.E.Prec)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"Wishart.Prec.inverse")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,-t)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Prec.inv <- SquareLoss(trueSigma,Post.E.Prec.inv,squareAdj)#norm(truePrec-Post.E.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Prec.inv)
        Stein.Post.E.Prec.inv <- SteinLoss(trueSigma,Post.E.Prec.inv,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Prec.inv)

#### MAP estimators

        MAP.Cov <- DAG.MAP(S[p:1,p:1],Adj=WishartAdj,U=U,alpha.c=alpha,alpha.b=b,n=n)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"MAP")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,-t)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MAP.Cov <- SquareLoss(trueSigma,MAP.Cov,squareAdj)#norm(trueSigma-MAP.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MAP.Cov)
        Stein.MAP.Cov <- SteinLoss(trueSigma,MAP.Cov,p)
        Stein.seq <- c(Stein.seq,Stein.MAP.Cov)
        #Matrix.List <- c(Matrix.List,MAP.Cov)
        #trueMatrix.List <- c(trueMatrix.List,trueSigma)
        
        MAP.Prec <- solve(MAP.Cov)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"MAP")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,-t)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MAP.Prec <- SquareLoss(truePrec,MAP.Prec,squareAdj)#norm(truePrec-MAP.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MAP.Prec)
        Stein.MAP.Prec <- SteinLoss(truePrec,MAP.Prec,p)
        Stein.seq <- c(Stein.seq,Stein.MAP.Prec)
        #Matrix.List <- c(Matrix.List,MAP.Prec)
        #trueMatrix.List <- c(trueMatrix.List,truePrec)
          
    }
    }


    
EvaluationSummary <- data.frame(p=Eval.p,n=Eval.n,alpha.c=Eval.alpha,alpha.b=Eval.b,Sparsity=Eval.sparsity,Strength=Eval.strength,Object=Obj.seq,Model=Eval.model,error=Frob.seq,Stein=Stein.seq,u=u.seq)
EvaluationSummary$t <- t
return(EvaluationSummary)
#return(list(EvalSum = EvaluationSummary,Mat=Matrix.List,trueMat=trueMatrix.List))

}






EstimationEvaluation.Cholesky <- function(M=10,p,n,sparsity,strength,u=1,alpha=1,b=3,seed=500,ident=FALSE,t=1){
library(pcalg)
library(Rgraphviz)
library(igraph)
library(plyr)
source("../Code/functions.R")

#### We will divide the study in two parts. In the first one, we will test the model on simulated data from three different perspectives: A) the edge connection strength; B) the sparsity and C) the dimensionality p.

u.seq <- Obj.seq <- Stein.seq <- Frob.seq <- Eval.alpha <- Eval.b <- Eval.n <- Eval.p <- Eval.sparsity <- Eval.strength <- Eval.model <- Eval.mcc <- Eval.shd <- NULL
trueMatrix.List <- Matrix.List <- list()

    #sparsity <- sparsity.seq
##theta is the probability that nodes with higher ordering will be connected to each node of lower order
    minw <- 0#strength-0.3
    maxw <- 1#strength+0.3
    ## min rho and max rho are the bound for direct effects of a parement node to one of its child node
    DAG.list <- GraphX.list <- list()
    set.seed(seed)
    for(k in 1: M){
    DAG.list[[k]] <- randomDAG(n=p,prob=sparsity,lB=minw,uB=maxw)
    true.DAG <- igraph.from.graphNEL(DAG.list[[k]])
    Adj <- get.adjacency(true.DAG)
    WishartAdj <- as.matrix(t(AdjTransform(Adj)))

    GraphX.list[[k]] <- cholesky.Gen(n=n,Adj=WishartAdj,lower=minw,upper=maxw)
    #GraphX.list[[k]] <- rmvDAG(n=n,dag=DAG.list[[k]],errDist="normal",mix=0)
    }
    U <- diag(rep(u,p))
    alpha.scale <- rep(alpha,p)

    for(k in 1:M){
        GraphX <- GraphX.list[[k]]$X
        DAG <- DAG.list[[k]]
        #tmp.U <- U

        true.DAG <- igraph.from.graphNEL(DAG)
        trueSigma <- GraphX.list[[k]]$Sigma
        sigma.scales <- diag(1/sqrt(diag(trueSigma)))
        trueSigma <- sigma.scales%*%trueSigma%*%sigma.scales
        Adj <- get.adjacency(true.DAG)
        WishartAdj <- t(AdjTransform(Adj))
        x <- scale(GraphX,TRUE,TRUE)
        scales <- apply(GraphX,2,sd)
        S <- t(x)%*%x/n
        squareAdj <- WishartAdj
        diag(squareAdj) <- 1
 


        
        #trueSigma <- trueSigma[p:1,p:1]
        truePrec <- solve(trueSigma)
        
        #MLE.Cov <- DAG.MLE(S[p:1,p:1],WishartAdj)
        MLE.Cov <- DAG.MLE(S,WishartAdj)        
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"MLE")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MLE.Cov <- SquareLoss(trueSigma,MLE.Cov,squareAdj)#norm(trueSigma-MLE.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MLE.Cov)
        Stein.MLE.Cov <- SteinLoss(trueSigma,MLE.Cov,p)
        Stein.seq <- c(Stein.seq,Stein.MLE.Cov)
        #Matrix.List <- c(Matrix.List,MLE.Cov)
        #trueMatrix.List <- c(trueMatrix.List,trueSigma)

        MLE.Prec <- solve(MLE.Cov)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"MLE")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MLE.Prec <- SquareLoss(truePrec,MLE.Prec,squareAdj)#norm(truePrec-MLE.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MLE.Prec)
        Stein.MLE.Prec <- SteinLoss(truePrec,MLE.Prec,p)
        Stein.seq <- c(Stein.seq,Stein.MLE.Prec)
        #Matrix.List <- c(Matrix.List,MLE.Prec)
        #trueMatrix.List <- c(trueMatrix.List,truePrec)


#### Evaluate estimation given by DAG Wishart posterior expectation
        pa.set <- apply(WishartAdj,2,function(x){which(x!=0)})
        Alpha <- rep(b,p)
        if(length(pa.set)>0){
        	pa.count <- unlist(lapply(pa.set,length))
        	Alpha <- Alpha + alpha.scale*pa.count
        }
        Alpha <- Alpha + n
        tmp.U <- U + n*S#[p:1,p:1]
      
        
        Post.E.Cov <- E.Sigma(alpha=Alpha,U=tmp.U,Adj=WishartAdj)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"WishartExpect")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Cov <- SquareLoss(trueSigma,Post.E.Cov,squareAdj)#norm(trueSigma-Post.E.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Cov)
        Stein.Post.E.Cov <- SteinLoss(trueSigma,Post.E.Cov,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Cov)
        #Matrix.List <- c(Matrix.List,Post.E.Cov)
        #trueMatrix.List <- c(trueMatrix.List,trueSigma)

        Post.E.Cov.inv <- solve(Post.E.Cov)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"Wishart.Cov.inverse")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Cov.inv <- SquareLoss(truePrec,Post.E.Cov.inv,squareAdj)#norm(trueSigma-Post.E.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Cov.inv)
        Stein.Post.E.Cov.inv <- SteinLoss(truePrec,Post.E.Cov.inv,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Cov.inv)
        

        Post.E.Prec <- E.Prec(alpha=Alpha,U=tmp.U,Adj=WishartAdj)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"WishartExpect")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Prec <- SquareLoss(truePrec,Post.E.Prec,squareAdj)#norm(truePrec-Post.E.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Prec)
        Stein.Post.E.Prec <- SteinLoss(truePrec,Post.E.Prec,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Prec)
        #Matrix.List <- c(Matrix.List,Post.E.Prec)
        #trueMatrix.List <- c(trueMatrix.List,truePrec)


        Post.E.Prec.inv <- solve(Post.E.Prec)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"Wishart.Prec.inverse")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Prec.inv <- SquareLoss(trueSigma,Post.E.Prec.inv,squareAdj)#norm(truePrec-Post.E.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Prec.inv)
        Stein.Post.E.Prec.inv <- SteinLoss(trueSigma,Post.E.Prec.inv,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Prec.inv)




#### MAP estimators

        MAP.Cov <- DAG.MAP(S[p:1,p:1],Adj=WishartAdj,U=U,alpha.c=alpha,alpha.b=b,n=n)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"MAP")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MAP.Cov <- SquareLoss(trueSigma,MAP.Cov,squareAdj)#norm(trueSigma-MAP.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MAP.Cov)
        Stein.MAP.Cov <- SteinLoss(trueSigma,MAP.Cov,p)
        Stein.seq <- c(Stein.seq,Stein.MAP.Cov)
        #Matrix.List <- c(Matrix.List,MAP.Cov)
        #trueMatrix.List <- c(trueMatrix.List,trueSigma)
        
        MAP.Prec <- solve(MAP.Cov)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"MAP")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MAP.Prec <- SquareLoss(truePrec,MAP.Prec,squareAdj)#norm(truePrec-MAP.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MAP.Prec)
        Stein.MAP.Prec <- SteinLoss(truePrec,MAP.Prec,p)
        Stein.seq <- c(Stein.seq,Stein.MAP.Prec)
        #Matrix.List <- c(Matrix.List,MAP.Prec)
        #trueMatrix.List <- c(trueMatrix.List,truePrec)
          
    }


    if(ident){
    for(k in 1:M){
        GraphX <- GraphX.list[[k]]$X
        DAG <- DAG.list[[k]]
        #tmp.U <- U

        true.DAG <- igraph.from.graphNEL(DAG)
        trueSigma <- GraphX.list[[k]]$Sigma
        sigma.scales <- diag(1/sqrt(diag(trueSigma)))
        trueSigma <- sigma.scales%*%trueSigma%*%sigma.scales
        Adj <- get.adjacency(true.DAG)
        WishartAdj <- t(AdjTransform(Adj))
        x <- scale(GraphX,TRUE,TRUE)
        scales <- apply(GraphX,2,sd)
        S <- t(x)%*%x/n
        squareAdj <- WishartAdj
        diag(squareAdj) <- 1
 
        
        #trueSigma <- trueSigma[p:1,p:1]
        truePrec <- solve(trueSigma)
        
        #MLE.Cov <- DAG.MLE(S[p:1,p:1],WishartAdj)
        MLE.Cov <- DAG.MLE(S,WishartAdj)        
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"MLE")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MLE.Cov <- SquareLoss(trueSigma,MLE.Cov,squareAdj)#norm(trueSigma-MLE.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MLE.Cov)
        Stein.MLE.Cov <- SteinLoss(trueSigma,MLE.Cov,p)
        Stein.seq <- c(Stein.seq,Stein.MLE.Cov)
        #Matrix.List <- c(Matrix.List,MLE.Cov)
        #trueMatrix.List <- c(trueMatrix.List,trueSigma)

        MLE.Prec <- solve(MLE.Cov)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"MLE")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MLE.Prec <- SquareLoss(truePrec,MLE.Prec,squareAdj)#norm(truePrec-MLE.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MLE.Prec)
        Stein.MLE.Prec <- SteinLoss(truePrec,MLE.Prec,p)
        Stein.seq <- c(Stein.seq,Stein.MLE.Prec)
        #Matrix.List <- c(Matrix.List,MLE.Prec)
        #trueMatrix.List <- c(trueMatrix.List,truePrec)


#### Evaluate estimation given by DAG Wishart posterior expectation
        pa.set <- apply(WishartAdj,2,function(x){which(x!=0)})
        Alpha <- rep(b,p)
        if(length(pa.set)>0){
        	pa.count <- unlist(lapply(pa.set,length))
        	Alpha <- Alpha + alpha.scale*pa.count
        }
        u <- -1
        U <- get.identity.u(alpha=Alpha,Adj=WishartAdj,t=t)

        Alpha <- Alpha + n
        tmp.U <- U + n*S#[p:1,p:1]
      
        
        Post.E.Cov <- E.Sigma(alpha=Alpha,U=tmp.U,Adj=WishartAdj)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"WishartExpect")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Cov <- SquareLoss(trueSigma,Post.E.Cov,squareAdj)#norm(trueSigma-Post.E.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Cov)
        Stein.Post.E.Cov <- SteinLoss(trueSigma,Post.E.Cov,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Cov)
        #Matrix.List <- c(Matrix.List,Post.E.Cov)
        #trueMatrix.List <- c(trueMatrix.List,trueSigma)

        Post.E.Cov.inv <- solve(Post.E.Cov)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"Wishart.Cov.inverse")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Cov.inv <- SquareLoss(truePrec,Post.E.Cov.inv,squareAdj)#norm(trueSigma-Post.E.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Cov.inv)
        Stein.Post.E.Cov.inv <- SteinLoss(truePrec,Post.E.Cov.inv,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Cov.inv)
        

        Post.E.Prec <- E.Prec(alpha=Alpha,U=tmp.U,Adj=WishartAdj)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"WishartExpect")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Prec <- SquareLoss(truePrec,Post.E.Prec,squareAdj)#norm(truePrec-Post.E.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Prec)
        Stein.Post.E.Prec <- SteinLoss(truePrec,Post.E.Prec,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Prec)
        #Matrix.List <- c(Matrix.List,Post.E.Prec)
        #trueMatrix.List <- c(trueMatrix.List,truePrec)

        Post.E.Prec.inv <- solve(Post.E.Prec)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"Wishart.Prec.inverse")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Prec.inv <- SquareLoss(trueSigma,Post.E.Prec.inv,squareAdj)#norm(truePrec-Post.E.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Prec.inv)
        Stein.Post.E.Prec.inv <- SteinLoss(trueSigma,Post.E.Prec.inv,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Prec.inv)

#### MAP estimators

        MAP.Cov <- DAG.MAP(S,Adj=WishartAdj,U=U,alpha.c=alpha,alpha.b=b,n=n)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"MAP")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MAP.Cov <- SquareLoss(trueSigma,MAP.Cov,squareAdj)#norm(trueSigma-MAP.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MAP.Cov)
        Stein.MAP.Cov <- SteinLoss(trueSigma,MAP.Cov,p)
        Stein.seq <- c(Stein.seq,Stein.MAP.Cov)
        #Matrix.List <- c(Matrix.List,MAP.Cov)
        #trueMatrix.List <- c(trueMatrix.List,trueSigma)
        
        MAP.Prec <- solve(MAP.Cov)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"MAP")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MAP.Prec <- SquareLoss(truePrec,MAP.Prec,squareAdj)#norm(truePrec-MAP.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MAP.Prec)
        Stein.MAP.Prec <- SteinLoss(truePrec,MAP.Prec,p)
        Stein.seq <- c(Stein.seq,Stein.MAP.Prec)
        #Matrix.List <- c(Matrix.List,MAP.Prec)
        #trueMatrix.List <- c(trueMatrix.List,truePrec)
          
    }
    }


    
EvaluationSummary <- data.frame(p=Eval.p,n=Eval.n,alpha.c=Eval.alpha,alpha.b=Eval.b,Sparsity=Eval.sparsity,Strength=Eval.strength,Object=Obj.seq,Model=Eval.model,error=Frob.seq,Stein=Stein.seq,u=u.seq)
EvaluationSummary$t <- t
return(EvaluationSummary)
#return(list(EvalSum = EvaluationSummary,Mat=Matrix.List,trueMat=trueMatrix.List))

}







EstimationEvaluation.Cholesky.fromMat <- function(M=10,n,sparsity,strength,u=1,alpha=1,b=3,seed=500,ident=FALSE,t=1,Mat){
library(pcalg)
library(Rgraphviz)
library(igraph)
library(plyr)
source("../Code/functions.R")

#### We will divide the study in two parts. In the first one, we will test the model on simulated data from three different perspectives: A) the edge connection strength; B) the sparsity and C) the dimensionality p.

u.seq <- Obj.seq <- Stein.seq <- Frob.seq <- Eval.alpha <- Eval.b <- Eval.n <- Eval.p <- Eval.sparsity <- Eval.strength <- Eval.model <- Eval.mcc <- Eval.shd <- NULL
trueMatrix.List <- Matrix.List <- list()
p <- nrow(Mat)
    #sparsity <- sparsity.seq
##theta is the probability that nodes with higher ordering will be connected to each node of lower order
    minw <- 0#strength-0.3
    maxw <- 1#strength+0.3
    ## min rho and max rho are the bound for direct effects of a parement node to one of its child node
    DAG.list <- GraphX.list <- list()
    set.seed(seed)
    for(k in 1: M){
    DAG.list[[k]] <- randomDAG(n=p,prob=sparsity,lB=minw,uB=maxw)
    true.DAG <- igraph.from.graphNEL(DAG.list[[k]])
    Adj <- get.adjacency(true.DAG)
    WishartAdj <- as.matrix(t(AdjTransform(Adj)))

    GraphX.list[[k]] <- cholesky.Gen.fromMat(n=n,Adj=WishartAdj,Mat=Mat)
    #GraphX.list[[k]] <- rmvDAG(n=n,dag=DAG.list[[k]],errDist="normal",mix=0)
    }
    U <- diag(rep(u,p))
    alpha.scale <- rep(alpha,p)

    for(k in 1:M){
        GraphX <- GraphX.list[[k]]$X
        DAG <- DAG.list[[k]]
        #tmp.U <- U

        true.DAG <- igraph.from.graphNEL(DAG)
        trueSigma <- GraphX.list[[k]]$Sigma
        sigma.scales <- diag(1/sqrt(diag(trueSigma)))
        trueSigma <- sigma.scales%*%trueSigma%*%sigma.scales
        Adj <- get.adjacency(true.DAG)
        WishartAdj <- t(AdjTransform(Adj))
        x <- scale(GraphX,TRUE,TRUE)
        scales <- apply(GraphX,2,sd)
        S <- t(x)%*%x/n
        squareAdj <- WishartAdj
        diag(squareAdj) <- 1
 


        
        #trueSigma <- trueSigma[p:1,p:1]
        truePrec <- solve(trueSigma)
        
        #MLE.Cov <- DAG.MLE(S[p:1,p:1],WishartAdj)
        MLE.Cov <- DAG.MLE(S,WishartAdj)        
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"MLE")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MLE.Cov <- SquareLoss(trueSigma,MLE.Cov,squareAdj)#norm(trueSigma-MLE.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MLE.Cov)
        Stein.MLE.Cov <- SteinLoss(trueSigma,MLE.Cov,p)
        Stein.seq <- c(Stein.seq,Stein.MLE.Cov)
        #Matrix.List <- c(Matrix.List,MLE.Cov)
        #trueMatrix.List <- c(trueMatrix.List,trueSigma)

        MLE.Prec <- solve(MLE.Cov)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"MLE")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MLE.Prec <- SquareLoss(truePrec,MLE.Prec,squareAdj)#norm(truePrec-MLE.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MLE.Prec)
        Stein.MLE.Prec <- SteinLoss(truePrec,MLE.Prec,p)
        Stein.seq <- c(Stein.seq,Stein.MLE.Prec)
        #Matrix.List <- c(Matrix.List,MLE.Prec)
        #trueMatrix.List <- c(trueMatrix.List,truePrec)


#### Evaluate estimation given by DAG Wishart posterior expectation
        pa.set <- apply(WishartAdj,2,function(x){which(x!=0)})
        Alpha <- rep(b,p)
        if(length(pa.set)>0){
        	pa.count <- unlist(lapply(pa.set,length))
        	Alpha <- Alpha + alpha.scale*pa.count
        }
        Alpha <- Alpha + n
        tmp.U <- U + n*S#[p:1,p:1]
      
        
        Post.E.Cov <- E.Sigma(alpha=Alpha,U=tmp.U,Adj=WishartAdj)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"WishartExpect")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Cov <- SquareLoss(trueSigma,Post.E.Cov,squareAdj)#norm(trueSigma-Post.E.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Cov)
        Stein.Post.E.Cov <- SteinLoss(trueSigma,Post.E.Cov,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Cov)
        #Matrix.List <- c(Matrix.List,Post.E.Cov)
        #trueMatrix.List <- c(trueMatrix.List,trueSigma)

        Post.E.Cov.inv <- solve(Post.E.Cov)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"Wishart.Cov.inverse")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Cov.inv <- SquareLoss(truePrec,Post.E.Cov.inv,squareAdj)#norm(trueSigma-Post.E.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Cov.inv)
        Stein.Post.E.Cov.inv <- SteinLoss(truePrec,Post.E.Cov.inv,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Cov.inv)
        

        Post.E.Prec <- E.Prec(alpha=Alpha,U=tmp.U,Adj=WishartAdj)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"WishartExpect")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Prec <- SquareLoss(truePrec,Post.E.Prec,squareAdj)#norm(truePrec-Post.E.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Prec)
        Stein.Post.E.Prec <- SteinLoss(truePrec,Post.E.Prec,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Prec)
        #Matrix.List <- c(Matrix.List,Post.E.Prec)
        #trueMatrix.List <- c(trueMatrix.List,truePrec)


        Post.E.Prec.inv <- solve(Post.E.Prec)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"Wishart.Prec.inverse")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Prec.inv <- SquareLoss(trueSigma,Post.E.Prec.inv,squareAdj)#norm(truePrec-Post.E.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Prec.inv)
        Stein.Post.E.Prec.inv <- SteinLoss(trueSigma,Post.E.Prec.inv,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Prec.inv)




#### MAP estimators

        MAP.Cov <- DAG.MAP(S[p:1,p:1],Adj=WishartAdj,U=U,alpha.c=alpha,alpha.b=b,n=n)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"MAP")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MAP.Cov <- SquareLoss(trueSigma,MAP.Cov,squareAdj)#norm(trueSigma-MAP.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MAP.Cov)
        Stein.MAP.Cov <- SteinLoss(trueSigma,MAP.Cov,p)
        Stein.seq <- c(Stein.seq,Stein.MAP.Cov)
        #Matrix.List <- c(Matrix.List,MAP.Cov)
        #trueMatrix.List <- c(trueMatrix.List,trueSigma)
        
        MAP.Prec <- solve(MAP.Cov)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"MAP")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MAP.Prec <- SquareLoss(truePrec,MAP.Prec,squareAdj)#norm(truePrec-MAP.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MAP.Prec)
        Stein.MAP.Prec <- SteinLoss(truePrec,MAP.Prec,p)
        Stein.seq <- c(Stein.seq,Stein.MAP.Prec)
        #Matrix.List <- c(Matrix.List,MAP.Prec)
        #trueMatrix.List <- c(trueMatrix.List,truePrec)
          
    }


    if(ident){
    for(k in 1:M){
        GraphX <- GraphX.list[[k]]$X
        DAG <- DAG.list[[k]]
        #tmp.U <- U

        true.DAG <- igraph.from.graphNEL(DAG)
        trueSigma <- GraphX.list[[k]]$Sigma
        sigma.scales <- diag(1/sqrt(diag(trueSigma)))
        trueSigma <- sigma.scales%*%trueSigma%*%sigma.scales
        Adj <- get.adjacency(true.DAG)
        WishartAdj <- t(AdjTransform(Adj))
        x <- scale(GraphX,TRUE,TRUE)
        scales <- apply(GraphX,2,sd)
        S <- t(x)%*%x/n
        squareAdj <- WishartAdj
        diag(squareAdj) <- 1
 
        
        #trueSigma <- trueSigma[p:1,p:1]
        truePrec <- solve(trueSigma)
        
        #MLE.Cov <- DAG.MLE(S[p:1,p:1],WishartAdj)
        MLE.Cov <- DAG.MLE(S,WishartAdj)        
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"MLE")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MLE.Cov <- SquareLoss(trueSigma,MLE.Cov,squareAdj)#norm(trueSigma-MLE.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MLE.Cov)
        Stein.MLE.Cov <- SteinLoss(trueSigma,MLE.Cov,p)
        Stein.seq <- c(Stein.seq,Stein.MLE.Cov)
        #Matrix.List <- c(Matrix.List,MLE.Cov)
        #trueMatrix.List <- c(trueMatrix.List,trueSigma)

        MLE.Prec <- solve(MLE.Cov)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"MLE")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MLE.Prec <- SquareLoss(truePrec,MLE.Prec,squareAdj)#norm(truePrec-MLE.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MLE.Prec)
        Stein.MLE.Prec <- SteinLoss(truePrec,MLE.Prec,p)
        Stein.seq <- c(Stein.seq,Stein.MLE.Prec)
        #Matrix.List <- c(Matrix.List,MLE.Prec)
        #trueMatrix.List <- c(trueMatrix.List,truePrec)


#### Evaluate estimation given by DAG Wishart posterior expectation
        pa.set <- apply(WishartAdj,2,function(x){which(x!=0)})
        Alpha <- rep(b,p)
        if(length(pa.set)>0){
        	pa.count <- unlist(lapply(pa.set,length))
        	Alpha <- Alpha + alpha.scale*pa.count
        }
        u <- -1
        U <- get.identity.u(alpha=Alpha,Adj=WishartAdj,t=t)

        Alpha <- Alpha + n
        tmp.U <- U + n*S#[p:1,p:1]
      
        
        Post.E.Cov <- E.Sigma(alpha=Alpha,U=tmp.U,Adj=WishartAdj)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"WishartExpect")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Cov <- SquareLoss(trueSigma,Post.E.Cov,squareAdj)#norm(trueSigma-Post.E.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Cov)
        Stein.Post.E.Cov <- SteinLoss(trueSigma,Post.E.Cov,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Cov)
        #Matrix.List <- c(Matrix.List,Post.E.Cov)
        #trueMatrix.List <- c(trueMatrix.List,trueSigma)

        Post.E.Cov.inv <- solve(Post.E.Cov)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"Wishart.Cov.inverse")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Cov.inv <- SquareLoss(truePrec,Post.E.Cov.inv,squareAdj)#norm(trueSigma-Post.E.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Cov.inv)
        Stein.Post.E.Cov.inv <- SteinLoss(truePrec,Post.E.Cov.inv,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Cov.inv)
        

        Post.E.Prec <- E.Prec(alpha=Alpha,U=tmp.U,Adj=WishartAdj)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"WishartExpect")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Prec <- SquareLoss(truePrec,Post.E.Prec,squareAdj)#norm(truePrec-Post.E.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Prec)
        Stein.Post.E.Prec <- SteinLoss(truePrec,Post.E.Prec,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Prec)
        #Matrix.List <- c(Matrix.List,Post.E.Prec)
        #trueMatrix.List <- c(trueMatrix.List,truePrec)

        Post.E.Prec.inv <- solve(Post.E.Prec)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"Wishart.Prec.inverse")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.Post.E.Prec.inv <- SquareLoss(trueSigma,Post.E.Prec.inv,squareAdj)#norm(truePrec-Post.E.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.Post.E.Prec.inv)
        Stein.Post.E.Prec.inv <- SteinLoss(trueSigma,Post.E.Prec.inv,p)
        Stein.seq <- c(Stein.seq,Stein.Post.E.Prec.inv)

#### MAP estimators

        MAP.Cov <- DAG.MAP(S,Adj=WishartAdj,U=U,alpha.c=alpha,alpha.b=b,n=n)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Covariance")
        Eval.model <- c(Eval.model,"MAP")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MAP.Cov <- SquareLoss(trueSigma,MAP.Cov,squareAdj)#norm(trueSigma-MAP.Cov,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MAP.Cov)
        Stein.MAP.Cov <- SteinLoss(trueSigma,MAP.Cov,p)
        Stein.seq <- c(Stein.seq,Stein.MAP.Cov)
        #Matrix.List <- c(Matrix.List,MAP.Cov)
        #trueMatrix.List <- c(trueMatrix.List,trueSigma)
        
        MAP.Prec <- solve(MAP.Cov)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Obj.seq <- c(Obj.seq,"Precision")
        Eval.model <- c(Eval.model,"MAP")
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        u.seq <- c(u.seq,u)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)        
        Frob.MAP.Prec <- SquareLoss(truePrec,MAP.Prec,squareAdj)#norm(truePrec-MAP.Prec,"F")/p 
        Frob.seq <- c(Frob.seq,Frob.MAP.Prec)
        Stein.MAP.Prec <- SteinLoss(truePrec,MAP.Prec,p)
        Stein.seq <- c(Stein.seq,Stein.MAP.Prec)
        #Matrix.List <- c(Matrix.List,MAP.Prec)
        #trueMatrix.List <- c(trueMatrix.List,truePrec)
          
    }
    }


    
EvaluationSummary <- data.frame(p=Eval.p,n=Eval.n,alpha.c=Eval.alpha,alpha.b=Eval.b,Sparsity=Eval.sparsity,Strength=Eval.strength,Object=Obj.seq,Model=Eval.model,error=Frob.seq,Stein=Stein.seq,u=u.seq)
EvaluationSummary$t <- t
return(EvaluationSummary)
#return(list(EvalSum = EvaluationSummary,Mat=Matrix.List,trueMat=trueMatrix.List))

}

