rm(list=ls())
require(doParallel)
#cl <- makeCluster(4)
#registerDoParallel(cl)
#trials <- 100
#ptime <- system.time(
# {
 # r <- foreach(icount(trials)) %dopar% {
  # tt <- rnorm(1)
  #}
 #}
#)

registerDoParallel(cores=4)

s.seq <- seq(0.005,0.02,by=0.005)
r <- foreach(i=1:4) %dopar%{
source("PerfEval.R") 
PerformanceEvaluation(M=50,p=200,n=100,sparsity=s.seq[i],strength=0.5,u=1,alpha=1,b=3,seed=500,X1=30,X3=0,iter=100,LassoNum=2,gm=0.5)
}

#save(r,file="NewEvalTestp200-Sparsity-Part1.Rda")
EvalSum <- NULL
for(k in 1:length(r)) EvalSum <- rbind(EvalSum,r[[k]]$Eval)
save(EvalSum,file="p200-Sparsity-Final-Part1.Rda")






