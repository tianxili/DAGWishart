PerformanceEvaluation <- function(M=10,p,n,sparsity,strength,u=1,alpha=1,b=3,seed=500,X1=20,X3=80,stop.num=20,iter.max=100,gm=1,LassoNum=2){
library(pcalg)
library(Rgraphviz)
library(igraph)
library(plyr)
source("../Code/functions.R")

#### We will divide the study in two parts. In the first one, we will test the model on simulated data from three different perspectives: A) the edge connection strength; B) the sparsity and C) the dimensionality p.

Stein.seq <- Frob.seq <- tp.seq <- fp.seq <- tn.seq <- fn.seq <- Eval.alpha <- Eval.b <- Eval.n <- Eval.p <- Eval.Sens <- Eval.Specific <- Eval.sparsity <- Eval.strength <- Eval.model <- Eval.precision <- Eval.recall <- Eval.mcc <- Eval.shd <- NULL
trueSigma.List <- Sigma.List <- list()

    #sparsity <- sparsity.seq
##theta is the probability that nodes with higher ordering will be connected to each node of lower order
    minw <- strength-0.3
    maxw <- strength+0.3
    ## min rho and max rho are the bound for direct effects of a parement node to one of its child node
    DAG.list <- GraphX.list <- list()
    set.seed(seed)
    for(k in 1: M){
    DAG.list[[k]] <- randomDAG(n=p,prob=sparsity,lB=minw,uB=maxw)
    GraphX.list[[k]] <- rmvDAG(n=n,dag=DAG.list[[k]],errDist="normal",mix=0)
    }
    U <- diag(rep(u,p))
    alpha.scale <- rep(alpha,p)

    for(k in 1:M){
        GraphX <- GraphX.list[[k]]
        DAG <- DAG.list[[k]]
        tmp.U <- U
        #stand.GraphX <- scale(GraphX,center=TRUE,scale=TRUE)
        #tmp.S <- t(stand.GraphX)%*%stand.GraphX/n
        #tmp.U <- (1-beta)
        test.p1 <- c(0.1,(1:15/15)^4*p)
        #test.p1 <- c(0.01,0.1,seq(0.25,0.95,by=0.1)*p)
        #test.p2 <- c(0.001,seq(0.1,40.1,by=5))
        Models <- DAGWishartSelection(x=GraphX,typeIp=test.p1,U=U,alpha.scale=alpha.scale,stop.num=stop.num,X3=X3,iter.max=iter.max,X1=X1,alpha.b=b,gm=gm)
        true.DAG <- igraph.from.graphNEL(DAG.list[[k]])
        best.Wishart <- which.max(Models$logScore)
        LassoDAG <- Models$LassoDAG[[LassoNum]]
        Naive.DAGWishart <- Models$WishartDAG[[LassoNum]]
        LaSDAW <- Models$WishartDAG[[best.Wishart]]
 #       LaSDAW.Adj <- as.matrix(get.adjacency(LaSDAW))
        ideal.Lasso.Index <- 1
        ideal.LassoDAG <- Models$LassoDAG[[ideal.Lasso.Index]]
 #       Lasso.Adj <- as.matrix(get.adjacency(ideal.LassoDAG))
        trueSigma <- GetTrueSigma(DAG)
        LaSDAWSigma <- Models$WishartSigma[[best.Wishart]]
        LassoSigma <- Models$LassoSigma[[ideal.Lasso.Index]]
#        for(j in 1:length(test.p1)){
 #           LassoDAG <- Models$LassoDAG[[j]]
 #           tmp.Eval <- Evaluation(true.DAG,LassoDAG)
 #           Eval.sparsity <- c(Eval.sparsity,sparsity)
 #           Eval.strength <- c(Eval.strength,strength)
 #           Eval.model <- c(Eval.model,paste("LassoDAG-",j,sep=""))
 #           Eval.precision <- c(Eval.precision,tmp.Eval$Precision)
 #           Eval.recall <- c(Eval.recall,tmp.Eval$Recall)
 #          Eval.mcc <- c(Eval.mcc,tmp.Eval$MCC)
 #           Eval.shd <- c(Eval.shd,tmp.Eval$SHD)
 #           Eval.Sens <- c(Eval.Sens,tmp.Eval$Sensitivity)
 #           Eval.Specific <- c(Eval.Specific,tmp.Eval$Specific)
 #           Eval.p <- c(Eval.p,p)
 #           Eval.n <- c(Eval.n,n)
 #           Eval.alpha <- c(Eval.alpha,alpha)
 #           Eval.b <- c(Eval.b,b)
 #           tp.seq <- c(tp.seq,tmp.Eval$TP)
 #           fp.seq <- c(fp.seq,tmp.Eval$FP)
 #           tn.seq <- c(tn.seq,tmp.Eval$TN)
 #           fn.seq <- c(fn.seq,tmp.Eval$FN)
#
 #       }


        tmp.Eval <- Evaluation(true.DAG,ideal.LassoDAG)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Eval.model <- c(Eval.model,"IdealLassoDAG")
        Eval.precision <- c(Eval.precision,tmp.Eval$Precision)
        Eval.recall <- c(Eval.recall,tmp.Eval$Recall)
        Eval.mcc <- c(Eval.mcc,tmp.Eval$MCC)
        Eval.shd <- c(Eval.shd,tmp.Eval$SHD)
        Eval.Sens <- c(Eval.Sens,tmp.Eval$Sensitivity)
        Eval.Specific <- c(Eval.Specific,tmp.Eval$Specific)
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)
	tp.seq <- c(tp.seq,tmp.Eval$TP)
	fp.seq <- c(fp.seq,tmp.Eval$FP)
	tn.seq <- c(tn.seq,tmp.Eval$TN)
	fn.seq <- c(fn.seq,tmp.Eval$FN)
 #       Lasso.index <- which(Lasso.Adj!=0)
 #       Frob.Lasso <- sum((trueSigma[Lasso.index]-LassoSigma[Lasso.index])^2)/sum((trueSigma[Lasso.index])^2)
        Frob.Lasso <- norm(trueSigma-LassoSigma,"F")/p#norm(trueSigma,"F") 
        Frob.seq <- c(Frob.seq,Frob.Lasso)
        Stein.Lasso <- SteinLoss(trueSigma,LassoSigma,p)
        Stein.seq <- c(Stein.seq,Stein.Lasso)
        Sigma.List[[2*k-1]] <- LassoSigma
        trueSigma.List[[2*k-1]] <- trueSigma


     
        tmp.Eval <- Evaluation(true.DAG,LaSDAW)
        Eval.sparsity <- c(Eval.sparsity,sparsity)
        Eval.strength <- c(Eval.strength,strength)
        Eval.model <- c(Eval.model,"LaSDAW")
        Eval.precision <- c(Eval.precision,tmp.Eval$Precision)
        Eval.recall <- c(Eval.recall,tmp.Eval$Recall)
        Eval.mcc <- c(Eval.mcc,tmp.Eval$MCC)
        Eval.shd <- c(Eval.shd,tmp.Eval$SHD)
        Eval.Sens <- c(Eval.Sens,tmp.Eval$Sensitivity)
        Eval.Specific <- c(Eval.Specific,tmp.Eval$Specific)
        Eval.p <- c(Eval.p,p)
        Eval.n <- c(Eval.n,n)
        Eval.alpha <- c(Eval.alpha,alpha)
        Eval.b <- c(Eval.b,b)
	tp.seq <- c(tp.seq,tmp.Eval$TP)
	fp.seq <- c(fp.seq,tmp.Eval$FP)
	tn.seq <- c(tn.seq,tmp.Eval$TN)
	fn.seq <- c(fn.seq,tmp.Eval$FN)
#        LaSDAW.index <- which(LaSDAW.Adj!=0)
#        Frob.LaSDAW <- sum((trueSigma[LaSDAW.index]-LaSDAWSigma[LaSDAW.index])^2)/sum((trueSigma[LaSDAW.index])^2)

        Frob.LaSDAW <- norm(trueSigma-LaSDAWSigma,"F")/p#norm(trueSigma,"F")
        Frob.seq <- c(Frob.seq,Frob.LaSDAW)
        Stein.LaSDAW <- SteinLoss(trueSigma,LaSDAWSigma,p)
        Stein.seq <- c(Stein.seq,Stein.LaSDAW)
        Sigma.List[[2*k]] <- LaSDAWSigma
        trueSigma.List[[2*k]] <- trueSigma

    }
    
EvaluationSummary <- data.frame(p=Eval.p,n=Eval.n,alpha.c=Eval.alpha,alpha.b=Eval.b,Sparsity=Eval.sparsity,Strength=Eval.strength,Model=Eval.model,Precision=Eval.precision,Recall=Eval.recall,MCC=Eval.mcc,SHD=Eval.shd,Sensitivity=Eval.Sens,Specific=Eval.Specific,TP=tp.seq,TN=tn.seq,FP=fp.seq,FN=fn.seq,error=Frob.seq,Stein=Stein.seq)

#ddply(EvaluationSummary,.(Model),function(x){apply(x[,-c(1,2,3)],2,mean)})
#return(EvaluationSummary)
return(list(EvalSum = EvaluationSummary,Sigma=Sigma.List,trueSigma=trueSigma.List))

}

